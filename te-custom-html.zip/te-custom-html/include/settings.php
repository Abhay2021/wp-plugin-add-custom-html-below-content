<?php 

//PLUGIN HTML PAGE
if(!function_exists('tech_html_page')){
    function tech_html_page(){
        if(!is_admin( )){ return;}
        ?>
        <div class="wrap">
            <h1><?= esc_html(get_admin_page_title() ); ?></h1>
            <form action="options.php" method="post">
                <?php 
                    settings_fields('tech-settings');
                    do_settings_sections('tech-add-custom-html');
                    submit_button('Save Changes', 'submit');
                ?>
            </form>
        </div>
        <?php
    }
   // add_action('admin_menu','te_add_dashboard_menu');
}

//ADD PLUGIN TO DASHBOARD MENU
if(!function_exists('te_add_dashboard_menu')){
    function te_add_dashboard_menu(){
        //add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position )
        add_menu_page('TechExpress Add Custom HTML Below All Post', 'TE Add html','manage_options','tech-add-custom-html', 'tech_html_page', 'dashicons-html',30 );
    }
    add_action('admin_menu','te_add_dashboard_menu');
}

if(!function_exists('clear_my_html_input')){
    function clear_my_html_input($data){
        $data = trim($data);
        $data = htmlspecialchars_decode($data);
        $data = htmlspecialchars($data);
        return $data;
    }
}

//PLUGIN SETTINGs
if(!function_exists('te_plugin_settings')){
    function te_plugin_settings(){
        //Registers a setting and its data 
        //register_setting($option_group,  $option_name)
        $args1 = array(
            'type' => 'string', 
            'sanitize_callback' => 'clear_my_html_input',
            'default' => NULL,
            );
        register_setting('tech-settings','tech_custom_html',$args1);
        $args2 = array(
            'type' => 'boolean', 
            'sanitize_callback' => 'sanitize_text_field',
            'default' => NULL,
            );
        register_setting('tech-settings','tech_is_publish',$args2);
        
        //Add a new section to a settings page.
        //add_settings_section( $id, $title, $callback, $page_slug )
        add_settings_section('tech_settings_section','TE custom HTML', 'tech_setting_section_cb', 'tech-add-custom-html' );

        //Add a new field to a section of a settings page.
        //add_settings_field( $id, $title, $callback, $page, $section, $args)
        add_settings_field('tech_html','Custom HTML','tech_html_field_cb','tech-add-custom-html','tech_settings_section');
        
        add_settings_field('tech_is_publish_html','Publish','tech_html_is_publish_cb','tech-add-custom-html','tech_settings_section');
    }
    add_action('admin_init','te_plugin_settings');
}
//CALLBACK PLUGIN SETTING > ADD SECTION
if(!function_exists('tech_setting_section_cb')){
    function tech_setting_section_cb(){
        echo '<p>Add custom html</p>';
    }
}

if(!function_exists('tech_html_field_cb')){
    function tech_html_field_cb(){
        $custom_html = get_option('tech_custom_html');// from register_setting
        ?>
        <textarea name='tech_custom_html' ><?php echo isset($custom_html)?htmlspecialchars_decode($custom_html):''; ?></textarea>
        <?php
    }
}

if(!function_exists('tech_html_is_publish_cb')){
    function tech_html_is_publish_cb(){
        $tech_is_publish = get_option('tech_is_publish');// from register_setting
        echo "<input type='checkbox' name='tech_is_publish' value='1'";
        if ( isset($tech_is_publish) && $tech_is_publish == '1' ) {
            echo ' checked';
        }
        echo '/>';
    }
}


?>