<?php 
/***
 * SHOW CUSTOM HTML BELOW CONTENT
 */
if(!function_exists('tech_show_custom_html_below_content')){
    function tech_show_custom_html_below_content($content){
        $tech_is_publish = get_option('tech_is_publish');
        if ( isset($tech_is_publish) && $tech_is_publish == '1' ) {
            $custom_html = get_option('tech_custom_html');
            $content .= htmlspecialchars_decode($custom_html);
        }
        return $content;
    }
    add_filter('the_content','tech_show_custom_html_below_content');
}

?>