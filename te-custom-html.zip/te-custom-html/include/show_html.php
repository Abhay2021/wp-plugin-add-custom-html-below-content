<?php 
/***
 * SHOW CUSTOM HTML BELOW CONTENT
 */
if(!function_exists('tech_show_custom_html_below_content')){
    function tech_show_custom_html_below_content($content){
        $tech_is_publish = get_option('tech_is_publish');
        if ( isset($tech_is_publish) && $tech_is_publish == '1' ) {
            $content .= tech_author_box();
            $custom_html = get_option('tech_custom_html');
            $content .= htmlspecialchars_decode($custom_html);
        }
        return $content;
    }
    add_filter('the_content','tech_show_custom_html_below_content');
}

if(!function_exists('tech_author_box')){
    function tech_author_box( ) {
    
        global $post;
        $author_box = '';
        // Detect single post with a post author
        if ( is_single() && isset( $post->post_author ) ) {
            $display_name = get_the_author_meta( 'display_name', $post->post_author );
            
            if ( empty( $display_name ) )
            $display_name = get_the_author_meta( 'nickname', $post->post_author );
            
            if (empty( $display_name ))
            $display_name = 'Author';
            
            $user_description = get_the_author_meta( 'user_description', $post->post_author );
            if (empty( $user_description ))
            $user_description ='I am the author of this post. I like to write unique posts. Hope this post will be helpful for you.';

            $image_url = get_option('tech_auhtor_box_image');
            if (!empty( $user_description )){
                $author_image = '<img alt="" src="'.$image_url.'" class="avatar avatar-90 photo" loading="lazy" width="90" height="90">';
            }else{
                $author_image = get_avatar( get_the_author_meta('user_email') , 90 );
            }

            if (!empty( $user_description ))
            $author_box = '<section class="author_box" >
            <div class="author_img">' .$author_image.'</div>
            <div class="author_details"> 
            <div class="author_name">'.nl2br($display_name).'</div>
            <div class="author_info">'. nl2br( $user_description ). '</small></div>
            </div>
            </section>';
        }
        return $author_box;
    }
}

?>