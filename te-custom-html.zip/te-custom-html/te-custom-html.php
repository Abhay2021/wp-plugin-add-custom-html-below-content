<?php 
/**
 * Plugin Name:       TechExpress Add Custom HTML and Author Box Below Posts
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Add custom HTML and author box below all post with this plugin.
 * Version:           1.0.1
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Randhir Jha
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tech-add-custom-html-plugin
 */
  //tech: te_custom_html
 // Make sure we don't expose any info if called directly
if ( !function_exists( 'add_action' ) ) {
	exit;
}

defined('TE_VERSION') OR define('TE_VERSION', '1.0.0');
defined('TECH_PLUGIN_DIR') OR define('TECH_PLUGIN_DIR',plugin_dir_url(__FILE__));

//include js and css files
if ( !function_exists( 'te_plugin_load_scripts' ) ) {
    function te_plugin_load_scripts($hook) {
        //wp_enqueue_script( $handle, $src, $deps, $ver, $in_footer ); 
        
        wp_enqueue_style( 'custom_css', TECH_PLUGIN_DIR.'assets/css/custom.css');
    }
    add_action('wp_enqueue_scripts', 'te_plugin_load_scripts');
}


if ( !function_exists( 'tech_admin_scripts' ) ) {
function tech_admin_scripts() {
    if (isset($_GET['page']) && $_GET['page'] == 'tech-add-custom-html') {
        wp_enqueue_media();
        wp_enqueue_script( 'custom_js', TECH_PLUGIN_DIR.'assets/js/custom.js', 'jquery', '1.0.0',true );
    }
}
add_action('admin_enqueue_scripts', 'tech_admin_scripts');
}

require plugin_dir_path(__FILE__).'include/settings.php';
require plugin_dir_path(__FILE__).'include/show_html.php';

?>